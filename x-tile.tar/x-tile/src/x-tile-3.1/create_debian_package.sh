#!/bin/sh

dpkg-buildpackage -b -d -tc

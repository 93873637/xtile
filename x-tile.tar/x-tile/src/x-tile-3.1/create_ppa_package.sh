#!/bin/sh

debuild -S -sa -i -I
